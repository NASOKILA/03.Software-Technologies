<?php

namespace AppBundle\Controller;

use AppBundle\Form\CalculatorFormType;
use AppBundle\Model\Calculator;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;



class CalculatorController extends Controller
{
    //Avtomatichno ni kazva che se namira v nqkakuv specialen namespace za kontrolleri

    // nasledqva specialen klas za kontrolleri v koito ima mnogo pomoshtni funkcii !

    //AVTOMATICHNO NI POKAZVA KAK SE POLZVAT KONTOLLERITE


    /**
     *@Route("/calculator", name="calculator_index")
     *
     */
    public function indexAction()
    {
        //I RENDERIRA NQKAKVO VIEW

        // SUZDAVAME SI PRAZEN KALKULATOR
        $calculator = new Calculator();
        // I GO PODAVAM NA CREATEFORM()
        // TRQBVA DA SI SUZDADEM FORMICHKA
        $form = $this->
        CreateForm(
            CalculatorFormType::class,
            $calculator);

        if($form->isValid()) // ako formulqrat e validen
        {
            var_dump($calculator);

        }

            return $this->render('Calculator/index.html.twig',
               [
                   'form' => $form->createView()
               ]);
    }
}
