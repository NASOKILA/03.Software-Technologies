<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir'))
        ]);
    }


    /**
     * @Route("/greet");
     *
     */
    public function greeting()
    {
            $name = "Atanas";
            $age = 24;
            $gender = "male";
            $handsome = true;

            // THE FIRST PARAMETER TAKES A VIEW THAT HAS TO END WITH html.twig
            // SUS ALT + ENTER VURHU VIEWTO SYNFONYSUZDAVA AVTOMATICHNO TEMPLATE ZA TOVA VIEW
            return $this->render('GreetingView.html.twig',
                [
                    //THIS IS THE SEOND PARAETER, THIS IS AN ARRAY OF VARIABLES
                    // IN HERE WE PUT ALL THE VARIABLES AND THEIR VALUES THAT WE WANT
                    // THE VIEW TO HAVE.
                    'Name' => $name,
                    'Age' => $age,
                    'Gender' => $gender,
                    'Handsome?' => $handsome
                ]);
    }
    //NAME NA ROUTA MOJEM DA GO POLZVAME KATO PROMENLIVA V SAMIQ LINK
    // I DA GO SETNEM DA OTGOVARQ NA DADENA STOINOST !

            /**
             *@Route("about-us", name="AboutUs");
             *
             */
            public function aboutUs()
            {
                return $this->render('aboutUsPage.html.twig');
            }
            // php bin/console server:run


}












