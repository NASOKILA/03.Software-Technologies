<?php

namespace AppBundle\Form;

use AppBundle\Model\Calculator;
use function PHPSTORM_META\type;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CalculatorFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // V TOVA METODCHE MOJEM DA S DEFINIRAME KAKVO DA NI IZLEZE VUV FORMATA
        // KATO INUTI I DRUGI, NE E NUJNO DA GI PRAVIM V HTML-A


        $builder->add('firstNum',NumberType::class)
                ->add('secondNum', NumberType::class);

    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'data_class' => Calculator::class
            ]
        );
    }


}
