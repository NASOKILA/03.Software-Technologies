<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 22/07/2017
 * Time: 0:52
 */

namespace AppBundle\Model;


class Calculator
{

/** @var  integer */
public $firstNumber;

/** @var  integer */
public $secondNumber;


    /**
     * @return int
     */
    public function getFirstNumber(): int
    {
        return $this->firstNumber;
    }

    /**
     * @param int $firstNumber
     */
    public function setFirstNumber(int $firstNumber)
    {
        $this->firstNumber = $firstNumber;
    }

    /**
     * @return int
     */
    public function getSecondNumber(): int
    {
        return $this->secondNumber;
    }

    /**
     * @param int $secondNumber
     */
    public function setSecondNumber(int $secondNumber)
    {
        $this->secondNumber = $secondNumber;
    }






}