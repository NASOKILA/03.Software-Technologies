<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_e376c751e330419d3f9a1a4b0a70adfbd1d2211ad6355062ee234a1596327f48 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8b717a114128c21bb5eed01d0ab03f6a348ea38fd9ceab54e1a0bdef53c8a22 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8b717a114128c21bb5eed01d0ab03f6a348ea38fd9ceab54e1a0bdef53c8a22->enter($__internal_e8b717a114128c21bb5eed01d0ab03f6a348ea38fd9ceab54e1a0bdef53c8a22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_989d01f72a6941eda107e246127a566d602586f410841e8f2d201ada88e2df97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_989d01f72a6941eda107e246127a566d602586f410841e8f2d201ada88e2df97->enter($__internal_989d01f72a6941eda107e246127a566d602586f410841e8f2d201ada88e2df97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e8b717a114128c21bb5eed01d0ab03f6a348ea38fd9ceab54e1a0bdef53c8a22->leave($__internal_e8b717a114128c21bb5eed01d0ab03f6a348ea38fd9ceab54e1a0bdef53c8a22_prof);

        
        $__internal_989d01f72a6941eda107e246127a566d602586f410841e8f2d201ada88e2df97->leave($__internal_989d01f72a6941eda107e246127a566d602586f410841e8f2d201ada88e2df97_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_f008abef48117d331c9c9f8e8d0443c2634a79516f32e1d025be138de2200b13 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f008abef48117d331c9c9f8e8d0443c2634a79516f32e1d025be138de2200b13->enter($__internal_f008abef48117d331c9c9f8e8d0443c2634a79516f32e1d025be138de2200b13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_31b4647ab2f824922fdfd6290405477079ef22f1e560b7265155e972c18b956d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31b4647ab2f824922fdfd6290405477079ef22f1e560b7265155e972c18b956d->enter($__internal_31b4647ab2f824922fdfd6290405477079ef22f1e560b7265155e972c18b956d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_31b4647ab2f824922fdfd6290405477079ef22f1e560b7265155e972c18b956d->leave($__internal_31b4647ab2f824922fdfd6290405477079ef22f1e560b7265155e972c18b956d_prof);

        
        $__internal_f008abef48117d331c9c9f8e8d0443c2634a79516f32e1d025be138de2200b13->leave($__internal_f008abef48117d331c9c9f8e8d0443c2634a79516f32e1d025be138de2200b13_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_54d0d7e1c28acdfe9e20c665d649814ff7b9814adc2e589ebb40932626077ea6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54d0d7e1c28acdfe9e20c665d649814ff7b9814adc2e589ebb40932626077ea6->enter($__internal_54d0d7e1c28acdfe9e20c665d649814ff7b9814adc2e589ebb40932626077ea6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2905a01335d1bf2c396865f9f285c2e41a6f981fea5fcce3473e36222b0d0d29 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2905a01335d1bf2c396865f9f285c2e41a6f981fea5fcce3473e36222b0d0d29->enter($__internal_2905a01335d1bf2c396865f9f285c2e41a6f981fea5fcce3473e36222b0d0d29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_2905a01335d1bf2c396865f9f285c2e41a6f981fea5fcce3473e36222b0d0d29->leave($__internal_2905a01335d1bf2c396865f9f285c2e41a6f981fea5fcce3473e36222b0d0d29_prof);

        
        $__internal_54d0d7e1c28acdfe9e20c665d649814ff7b9814adc2e589ebb40932626077ea6->leave($__internal_54d0d7e1c28acdfe9e20c665d649814ff7b9814adc2e589ebb40932626077ea6_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_2a55ec1280ca3261e2114735047187f2426789fd6fb8e629e02b4eb5a25a5134 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a55ec1280ca3261e2114735047187f2426789fd6fb8e629e02b4eb5a25a5134->enter($__internal_2a55ec1280ca3261e2114735047187f2426789fd6fb8e629e02b4eb5a25a5134_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_046baf541976ded5344bd8de617ff130db26b401fddb535ab9af1fa4eb79349f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_046baf541976ded5344bd8de617ff130db26b401fddb535ab9af1fa4eb79349f->enter($__internal_046baf541976ded5344bd8de617ff130db26b401fddb535ab9af1fa4eb79349f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_046baf541976ded5344bd8de617ff130db26b401fddb535ab9af1fa4eb79349f->leave($__internal_046baf541976ded5344bd8de617ff130db26b401fddb535ab9af1fa4eb79349f_prof);

        
        $__internal_2a55ec1280ca3261e2114735047187f2426789fd6fb8e629e02b4eb5a25a5134->leave($__internal_2a55ec1280ca3261e2114735047187f2426789fd6fb8e629e02b4eb5a25a5134_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\xmp\\htdocs\\GGG\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
