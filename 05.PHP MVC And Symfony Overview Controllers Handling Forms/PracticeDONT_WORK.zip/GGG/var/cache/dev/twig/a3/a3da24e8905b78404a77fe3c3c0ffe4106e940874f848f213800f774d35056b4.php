<?php

/* base.html.twig */
class __TwigTemplate_93e2499d03c6402ea1e3906495568257ed0120721f7f5badb0e11600e82927c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c33f7da14e4b4b1e59b95ac03b2922f55cbec10d5268f2b35caaf3a5914fff43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c33f7da14e4b4b1e59b95ac03b2922f55cbec10d5268f2b35caaf3a5914fff43->enter($__internal_c33f7da14e4b4b1e59b95ac03b2922f55cbec10d5268f2b35caaf3a5914fff43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_6c287da620ce0e7583f606173da638072f0cb661bda65d9f65b0f96ca90cc7c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c287da620ce0e7583f606173da638072f0cb661bda65d9f65b0f96ca90cc7c7->enter($__internal_6c287da620ce0e7583f606173da638072f0cb661bda65d9f65b0f96ca90cc7c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_c33f7da14e4b4b1e59b95ac03b2922f55cbec10d5268f2b35caaf3a5914fff43->leave($__internal_c33f7da14e4b4b1e59b95ac03b2922f55cbec10d5268f2b35caaf3a5914fff43_prof);

        
        $__internal_6c287da620ce0e7583f606173da638072f0cb661bda65d9f65b0f96ca90cc7c7->leave($__internal_6c287da620ce0e7583f606173da638072f0cb661bda65d9f65b0f96ca90cc7c7_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_237a457735386b92bbcc2a62e30249ef1a8ddd33659fc068139b49d35035c229 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_237a457735386b92bbcc2a62e30249ef1a8ddd33659fc068139b49d35035c229->enter($__internal_237a457735386b92bbcc2a62e30249ef1a8ddd33659fc068139b49d35035c229_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e59cf0ff8f25d28823c79cca3d4ccaeaa0b2b72cbbf4f06e99f6594af4738f30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e59cf0ff8f25d28823c79cca3d4ccaeaa0b2b72cbbf4f06e99f6594af4738f30->enter($__internal_e59cf0ff8f25d28823c79cca3d4ccaeaa0b2b72cbbf4f06e99f6594af4738f30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_e59cf0ff8f25d28823c79cca3d4ccaeaa0b2b72cbbf4f06e99f6594af4738f30->leave($__internal_e59cf0ff8f25d28823c79cca3d4ccaeaa0b2b72cbbf4f06e99f6594af4738f30_prof);

        
        $__internal_237a457735386b92bbcc2a62e30249ef1a8ddd33659fc068139b49d35035c229->leave($__internal_237a457735386b92bbcc2a62e30249ef1a8ddd33659fc068139b49d35035c229_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_494a75e38e12504dbc70e22d1e9e3f2f8f88569979720e23e02ec609208900b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_494a75e38e12504dbc70e22d1e9e3f2f8f88569979720e23e02ec609208900b8->enter($__internal_494a75e38e12504dbc70e22d1e9e3f2f8f88569979720e23e02ec609208900b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_104e5d6218b7ae21d78c36c501113dfe1e4908efe6caf4748a5be12a93f05f31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_104e5d6218b7ae21d78c36c501113dfe1e4908efe6caf4748a5be12a93f05f31->enter($__internal_104e5d6218b7ae21d78c36c501113dfe1e4908efe6caf4748a5be12a93f05f31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_104e5d6218b7ae21d78c36c501113dfe1e4908efe6caf4748a5be12a93f05f31->leave($__internal_104e5d6218b7ae21d78c36c501113dfe1e4908efe6caf4748a5be12a93f05f31_prof);

        
        $__internal_494a75e38e12504dbc70e22d1e9e3f2f8f88569979720e23e02ec609208900b8->leave($__internal_494a75e38e12504dbc70e22d1e9e3f2f8f88569979720e23e02ec609208900b8_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_a3be3c6ce975db9ba6856f2119a7fbfe1488b9c0a6eb4dec0bc966fdda9d1bd7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3be3c6ce975db9ba6856f2119a7fbfe1488b9c0a6eb4dec0bc966fdda9d1bd7->enter($__internal_a3be3c6ce975db9ba6856f2119a7fbfe1488b9c0a6eb4dec0bc966fdda9d1bd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_547183b5242f9330cac757ef00d9eea3769ffcc7ea336aa9c199416583d892fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_547183b5242f9330cac757ef00d9eea3769ffcc7ea336aa9c199416583d892fb->enter($__internal_547183b5242f9330cac757ef00d9eea3769ffcc7ea336aa9c199416583d892fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_547183b5242f9330cac757ef00d9eea3769ffcc7ea336aa9c199416583d892fb->leave($__internal_547183b5242f9330cac757ef00d9eea3769ffcc7ea336aa9c199416583d892fb_prof);

        
        $__internal_a3be3c6ce975db9ba6856f2119a7fbfe1488b9c0a6eb4dec0bc966fdda9d1bd7->leave($__internal_a3be3c6ce975db9ba6856f2119a7fbfe1488b9c0a6eb4dec0bc966fdda9d1bd7_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_82ab91456aacdf96ed0e4723d169a8f5de51f5624ca481b4b86eb8d85b700fc3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82ab91456aacdf96ed0e4723d169a8f5de51f5624ca481b4b86eb8d85b700fc3->enter($__internal_82ab91456aacdf96ed0e4723d169a8f5de51f5624ca481b4b86eb8d85b700fc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_162b32141be8161868a7c6333cbb485fe1b1f60f38f532a24c4aa3bbd41d6b97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_162b32141be8161868a7c6333cbb485fe1b1f60f38f532a24c4aa3bbd41d6b97->enter($__internal_162b32141be8161868a7c6333cbb485fe1b1f60f38f532a24c4aa3bbd41d6b97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_162b32141be8161868a7c6333cbb485fe1b1f60f38f532a24c4aa3bbd41d6b97->leave($__internal_162b32141be8161868a7c6333cbb485fe1b1f60f38f532a24c4aa3bbd41d6b97_prof);

        
        $__internal_82ab91456aacdf96ed0e4723d169a8f5de51f5624ca481b4b86eb8d85b700fc3->leave($__internal_82ab91456aacdf96ed0e4723d169a8f5de51f5624ca481b4b86eb8d85b700fc3_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xmp\\htdocs\\GGG\\app\\Resources\\views\\base.html.twig");
    }
}
