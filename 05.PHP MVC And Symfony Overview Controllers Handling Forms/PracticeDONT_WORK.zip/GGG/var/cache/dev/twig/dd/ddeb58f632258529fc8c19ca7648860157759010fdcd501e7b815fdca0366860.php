<?php

/* GreetingView.html.twig */
class __TwigTemplate_a7dfd48a3864b6d75940bd83786f2aab258612e044fa4fb8c17ca178dd05c986 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aac93a9d51c8ee4c15a03e901eab1f391d63942900077fb7c08d143cb275a760 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aac93a9d51c8ee4c15a03e901eab1f391d63942900077fb7c08d143cb275a760->enter($__internal_aac93a9d51c8ee4c15a03e901eab1f391d63942900077fb7c08d143cb275a760_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "GreetingView.html.twig"));

        $__internal_14192840d61fe0e5f3bd1c78e0ae59c846dbbab98083137376402afaa2479ce4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14192840d61fe0e5f3bd1c78e0ae59c846dbbab98083137376402afaa2479ce4->enter($__internal_14192840d61fe0e5f3bd1c78e0ae59c846dbbab98083137376402afaa2479ce4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "GreetingView.html.twig"));

        // line 1
        echo "
<h1>Hy, my name is ";
        // line 2
        echo twig_escape_filter($this->env, ($context["Name"] ?? $this->getContext($context, "Name")), "html", null, true);
        echo ", I am ";
        echo twig_escape_filter($this->env, ($context["Age"] ?? $this->getContext($context, "Age")), "html", null, true);
        echo " years old ";
        echo twig_escape_filter($this->env, ($context["Gender"] ?? $this->getContext($context, "Gender")), "html", null, true);
        echo ".</h1>


";
        
        $__internal_aac93a9d51c8ee4c15a03e901eab1f391d63942900077fb7c08d143cb275a760->leave($__internal_aac93a9d51c8ee4c15a03e901eab1f391d63942900077fb7c08d143cb275a760_prof);

        
        $__internal_14192840d61fe0e5f3bd1c78e0ae59c846dbbab98083137376402afaa2479ce4->leave($__internal_14192840d61fe0e5f3bd1c78e0ae59c846dbbab98083137376402afaa2479ce4_prof);

    }

    public function getTemplateName()
    {
        return "GreetingView.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
<h1>Hy, my name is {{ Name }}, I am {{ Age }} years old {{ Gender }}.</h1>


", "GreetingView.html.twig", "C:\\xmp\\htdocs\\GGG\\app\\Resources\\views\\GreetingView.html.twig");
    }
}
