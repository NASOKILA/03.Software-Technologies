<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_0ef46ff3e00be850b375145c4de69a72941605b1b30816a42d1a36aa92bc080f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_43edafb79abd42759db15d5d29caa3caab1577f8f18f03cd1329a2c8bf0102e7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_43edafb79abd42759db15d5d29caa3caab1577f8f18f03cd1329a2c8bf0102e7->enter($__internal_43edafb79abd42759db15d5d29caa3caab1577f8f18f03cd1329a2c8bf0102e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_a4f3bb31831e67789d8aa5fde3ee9e615098f1ce86715478d0e19d919e734904 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4f3bb31831e67789d8aa5fde3ee9e615098f1ce86715478d0e19d919e734904->enter($__internal_a4f3bb31831e67789d8aa5fde3ee9e615098f1ce86715478d0e19d919e734904_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_43edafb79abd42759db15d5d29caa3caab1577f8f18f03cd1329a2c8bf0102e7->leave($__internal_43edafb79abd42759db15d5d29caa3caab1577f8f18f03cd1329a2c8bf0102e7_prof);

        
        $__internal_a4f3bb31831e67789d8aa5fde3ee9e615098f1ce86715478d0e19d919e734904->leave($__internal_a4f3bb31831e67789d8aa5fde3ee9e615098f1ce86715478d0e19d919e734904_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_dcde2cc94a40f73c31777e9bea34bbcfc5cfa8c1e8310e293db7f77a36564be2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dcde2cc94a40f73c31777e9bea34bbcfc5cfa8c1e8310e293db7f77a36564be2->enter($__internal_dcde2cc94a40f73c31777e9bea34bbcfc5cfa8c1e8310e293db7f77a36564be2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9c0574a0caa310d8c5470d5e4bcee07de06345206c61616a1dc7121026270289 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c0574a0caa310d8c5470d5e4bcee07de06345206c61616a1dc7121026270289->enter($__internal_9c0574a0caa310d8c5470d5e4bcee07de06345206c61616a1dc7121026270289_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_9c0574a0caa310d8c5470d5e4bcee07de06345206c61616a1dc7121026270289->leave($__internal_9c0574a0caa310d8c5470d5e4bcee07de06345206c61616a1dc7121026270289_prof);

        
        $__internal_dcde2cc94a40f73c31777e9bea34bbcfc5cfa8c1e8310e293db7f77a36564be2->leave($__internal_dcde2cc94a40f73c31777e9bea34bbcfc5cfa8c1e8310e293db7f77a36564be2_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_601cdb9261ea7b716ca5257446ae0baf3ea52a7c61cf4a3cf7aed41b32ce035d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_601cdb9261ea7b716ca5257446ae0baf3ea52a7c61cf4a3cf7aed41b32ce035d->enter($__internal_601cdb9261ea7b716ca5257446ae0baf3ea52a7c61cf4a3cf7aed41b32ce035d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ad0c113fd69bfc43afa80d455c963d280cf2ab05dce419dfec1f8f6a60da590f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad0c113fd69bfc43afa80d455c963d280cf2ab05dce419dfec1f8f6a60da590f->enter($__internal_ad0c113fd69bfc43afa80d455c963d280cf2ab05dce419dfec1f8f6a60da590f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_ad0c113fd69bfc43afa80d455c963d280cf2ab05dce419dfec1f8f6a60da590f->leave($__internal_ad0c113fd69bfc43afa80d455c963d280cf2ab05dce419dfec1f8f6a60da590f_prof);

        
        $__internal_601cdb9261ea7b716ca5257446ae0baf3ea52a7c61cf4a3cf7aed41b32ce035d->leave($__internal_601cdb9261ea7b716ca5257446ae0baf3ea52a7c61cf4a3cf7aed41b32ce035d_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_91e8f7440555b5db3ded48288fc6d54a12841b196e5cbc975296940792664b1a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_91e8f7440555b5db3ded48288fc6d54a12841b196e5cbc975296940792664b1a->enter($__internal_91e8f7440555b5db3ded48288fc6d54a12841b196e5cbc975296940792664b1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c829b6e82730a7d5bb67f6c14ed95a5332977dfea6ed1ab1875c7e14624e9acf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c829b6e82730a7d5bb67f6c14ed95a5332977dfea6ed1ab1875c7e14624e9acf->enter($__internal_c829b6e82730a7d5bb67f6c14ed95a5332977dfea6ed1ab1875c7e14624e9acf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_c829b6e82730a7d5bb67f6c14ed95a5332977dfea6ed1ab1875c7e14624e9acf->leave($__internal_c829b6e82730a7d5bb67f6c14ed95a5332977dfea6ed1ab1875c7e14624e9acf_prof);

        
        $__internal_91e8f7440555b5db3ded48288fc6d54a12841b196e5cbc975296940792664b1a->leave($__internal_91e8f7440555b5db3ded48288fc6d54a12841b196e5cbc975296940792664b1a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "C:\\xmp\\htdocs\\GGG\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\layout.html.twig");
    }
}
