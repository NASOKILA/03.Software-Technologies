<?php

/* aboutUsPage.html.twig */
class __TwigTemplate_7952543d0dd753698ab831bf1dca0c3ac32b9198afb299bb0df0254bfc122d88 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b41f380feabd5092b0f035ee247e5bea760611c604d1caeec29ec94927c53ddb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b41f380feabd5092b0f035ee247e5bea760611c604d1caeec29ec94927c53ddb->enter($__internal_b41f380feabd5092b0f035ee247e5bea760611c604d1caeec29ec94927c53ddb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "aboutUsPage.html.twig"));

        $__internal_02e2468566ac9b85ee1a4b02665803f19a334a9d6fb49da19b50517aae8500eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02e2468566ac9b85ee1a4b02665803f19a334a9d6fb49da19b50517aae8500eb->enter($__internal_02e2468566ac9b85ee1a4b02665803f19a334a9d6fb49da19b50517aae8500eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "aboutUsPage.html.twig"));

        // line 1
        echo "
<h1>THIS IS THE ABOUT US PAGE !</h1>
";
        
        $__internal_b41f380feabd5092b0f035ee247e5bea760611c604d1caeec29ec94927c53ddb->leave($__internal_b41f380feabd5092b0f035ee247e5bea760611c604d1caeec29ec94927c53ddb_prof);

        
        $__internal_02e2468566ac9b85ee1a4b02665803f19a334a9d6fb49da19b50517aae8500eb->leave($__internal_02e2468566ac9b85ee1a4b02665803f19a334a9d6fb49da19b50517aae8500eb_prof);

    }

    public function getTemplateName()
    {
        return "aboutUsPage.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
<h1>THIS IS THE ABOUT US PAGE !</h1>
", "aboutUsPage.html.twig", "C:\\xmp\\htdocs\\GGG\\app\\Resources\\views\\aboutUsPage.html.twig");
    }
}
