<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_09886c37796d81d574b2448cf2a22ea32da8dad546b69f22c376ce19a869ce97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2bff4cdbf5ec886a9f593638cd83fc93464213513d59db5cdf4c89a4047118c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2bff4cdbf5ec886a9f593638cd83fc93464213513d59db5cdf4c89a4047118c9->enter($__internal_2bff4cdbf5ec886a9f593638cd83fc93464213513d59db5cdf4c89a4047118c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_795be820a2d9fc4614de11f77f96e778efd8b973fa859da31f485f25aa942a42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_795be820a2d9fc4614de11f77f96e778efd8b973fa859da31f485f25aa942a42->enter($__internal_795be820a2d9fc4614de11f77f96e778efd8b973fa859da31f485f25aa942a42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2bff4cdbf5ec886a9f593638cd83fc93464213513d59db5cdf4c89a4047118c9->leave($__internal_2bff4cdbf5ec886a9f593638cd83fc93464213513d59db5cdf4c89a4047118c9_prof);

        
        $__internal_795be820a2d9fc4614de11f77f96e778efd8b973fa859da31f485f25aa942a42->leave($__internal_795be820a2d9fc4614de11f77f96e778efd8b973fa859da31f485f25aa942a42_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_36608db15b8ee3950656858543e58ce024b2bede8f5a15b554fafb5880a0829d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36608db15b8ee3950656858543e58ce024b2bede8f5a15b554fafb5880a0829d->enter($__internal_36608db15b8ee3950656858543e58ce024b2bede8f5a15b554fafb5880a0829d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_d2377517b6732edfc5540650f6d000e935f60124aa52d8f4dbeaebe1f636547a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2377517b6732edfc5540650f6d000e935f60124aa52d8f4dbeaebe1f636547a->enter($__internal_d2377517b6732edfc5540650f6d000e935f60124aa52d8f4dbeaebe1f636547a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_d2377517b6732edfc5540650f6d000e935f60124aa52d8f4dbeaebe1f636547a->leave($__internal_d2377517b6732edfc5540650f6d000e935f60124aa52d8f4dbeaebe1f636547a_prof);

        
        $__internal_36608db15b8ee3950656858543e58ce024b2bede8f5a15b554fafb5880a0829d->leave($__internal_36608db15b8ee3950656858543e58ce024b2bede8f5a15b554fafb5880a0829d_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_65f4d662ce847c7608d5c8d18d202eba0c315e3143fa6110e24a806450f76129 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65f4d662ce847c7608d5c8d18d202eba0c315e3143fa6110e24a806450f76129->enter($__internal_65f4d662ce847c7608d5c8d18d202eba0c315e3143fa6110e24a806450f76129_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_7944143c3f77e2ee3443ffb4f8eea14b68a045a0b5afcb76df3c30aa73cb6424 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7944143c3f77e2ee3443ffb4f8eea14b68a045a0b5afcb76df3c30aa73cb6424->enter($__internal_7944143c3f77e2ee3443ffb4f8eea14b68a045a0b5afcb76df3c30aa73cb6424_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7944143c3f77e2ee3443ffb4f8eea14b68a045a0b5afcb76df3c30aa73cb6424->leave($__internal_7944143c3f77e2ee3443ffb4f8eea14b68a045a0b5afcb76df3c30aa73cb6424_prof);

        
        $__internal_65f4d662ce847c7608d5c8d18d202eba0c315e3143fa6110e24a806450f76129->leave($__internal_65f4d662ce847c7608d5c8d18d202eba0c315e3143fa6110e24a806450f76129_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_503a24678c7f848655489ea96432cbe1c843dfbd5e83108a90c7d9e6151992ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_503a24678c7f848655489ea96432cbe1c843dfbd5e83108a90c7d9e6151992ed->enter($__internal_503a24678c7f848655489ea96432cbe1c843dfbd5e83108a90c7d9e6151992ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9d4a4efb7be66d466f53ddfd63b4984908d7997f7a60933ad998bcf1e38aa988 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d4a4efb7be66d466f53ddfd63b4984908d7997f7a60933ad998bcf1e38aa988->enter($__internal_9d4a4efb7be66d466f53ddfd63b4984908d7997f7a60933ad998bcf1e38aa988_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_9d4a4efb7be66d466f53ddfd63b4984908d7997f7a60933ad998bcf1e38aa988->leave($__internal_9d4a4efb7be66d466f53ddfd63b4984908d7997f7a60933ad998bcf1e38aa988_prof);

        
        $__internal_503a24678c7f848655489ea96432cbe1c843dfbd5e83108a90c7d9e6151992ed->leave($__internal_503a24678c7f848655489ea96432cbe1c843dfbd5e83108a90c7d9e6151992ed_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xmp\\htdocs\\GGG\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
