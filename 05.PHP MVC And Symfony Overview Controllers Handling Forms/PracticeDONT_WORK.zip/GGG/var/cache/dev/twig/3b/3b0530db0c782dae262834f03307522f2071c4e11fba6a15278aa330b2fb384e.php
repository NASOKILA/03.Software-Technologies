<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_f32ad73c9bc804e7d7685ce925e27ce9c7daa98efc0b9a8c89227d7076a75563 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ad9523ae2acad8ea719a3dc0ca789f98ccf970d64696dc54db7d1e942263ead = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ad9523ae2acad8ea719a3dc0ca789f98ccf970d64696dc54db7d1e942263ead->enter($__internal_3ad9523ae2acad8ea719a3dc0ca789f98ccf970d64696dc54db7d1e942263ead_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_b06302a5dded7f0852cb8fb10d0a222436874e3f5f114aacf348c96f08687259 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b06302a5dded7f0852cb8fb10d0a222436874e3f5f114aacf348c96f08687259->enter($__internal_b06302a5dded7f0852cb8fb10d0a222436874e3f5f114aacf348c96f08687259_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3ad9523ae2acad8ea719a3dc0ca789f98ccf970d64696dc54db7d1e942263ead->leave($__internal_3ad9523ae2acad8ea719a3dc0ca789f98ccf970d64696dc54db7d1e942263ead_prof);

        
        $__internal_b06302a5dded7f0852cb8fb10d0a222436874e3f5f114aacf348c96f08687259->leave($__internal_b06302a5dded7f0852cb8fb10d0a222436874e3f5f114aacf348c96f08687259_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a538d41f06999fe7b5fc289eec7f88001ef04d15e9c611497c7e5b4645576899 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a538d41f06999fe7b5fc289eec7f88001ef04d15e9c611497c7e5b4645576899->enter($__internal_a538d41f06999fe7b5fc289eec7f88001ef04d15e9c611497c7e5b4645576899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_f0ba35f45dc43a9395fc7947b87da8381d28d629f1c2e5d16663bf1974ae0a19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0ba35f45dc43a9395fc7947b87da8381d28d629f1c2e5d16663bf1974ae0a19->enter($__internal_f0ba35f45dc43a9395fc7947b87da8381d28d629f1c2e5d16663bf1974ae0a19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_f0ba35f45dc43a9395fc7947b87da8381d28d629f1c2e5d16663bf1974ae0a19->leave($__internal_f0ba35f45dc43a9395fc7947b87da8381d28d629f1c2e5d16663bf1974ae0a19_prof);

        
        $__internal_a538d41f06999fe7b5fc289eec7f88001ef04d15e9c611497c7e5b4645576899->leave($__internal_a538d41f06999fe7b5fc289eec7f88001ef04d15e9c611497c7e5b4645576899_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_36fc451d18020ce45946a9572b5aea5f471acedf2feabbe4dc8ced077b39b919 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36fc451d18020ce45946a9572b5aea5f471acedf2feabbe4dc8ced077b39b919->enter($__internal_36fc451d18020ce45946a9572b5aea5f471acedf2feabbe4dc8ced077b39b919_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_f13be1375536011ddb8c310deb6ea60bb289a0222c135e77f386bbcc495992f7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f13be1375536011ddb8c310deb6ea60bb289a0222c135e77f386bbcc495992f7->enter($__internal_f13be1375536011ddb8c310deb6ea60bb289a0222c135e77f386bbcc495992f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_f13be1375536011ddb8c310deb6ea60bb289a0222c135e77f386bbcc495992f7->leave($__internal_f13be1375536011ddb8c310deb6ea60bb289a0222c135e77f386bbcc495992f7_prof);

        
        $__internal_36fc451d18020ce45946a9572b5aea5f471acedf2feabbe4dc8ced077b39b919->leave($__internal_36fc451d18020ce45946a9572b5aea5f471acedf2feabbe4dc8ced077b39b919_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d012b43f74495387ea8ffe232abf03b2034bbd2188bec35a1085f4467d2a7c53 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d012b43f74495387ea8ffe232abf03b2034bbd2188bec35a1085f4467d2a7c53->enter($__internal_d012b43f74495387ea8ffe232abf03b2034bbd2188bec35a1085f4467d2a7c53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_ec0a5718730d7c9c3eb002d2bbaf8ac2906ed5ac9b38613c4a99681ea03b4f70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec0a5718730d7c9c3eb002d2bbaf8ac2906ed5ac9b38613c4a99681ea03b4f70->enter($__internal_ec0a5718730d7c9c3eb002d2bbaf8ac2906ed5ac9b38613c4a99681ea03b4f70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_ec0a5718730d7c9c3eb002d2bbaf8ac2906ed5ac9b38613c4a99681ea03b4f70->leave($__internal_ec0a5718730d7c9c3eb002d2bbaf8ac2906ed5ac9b38613c4a99681ea03b4f70_prof);

        
        $__internal_d012b43f74495387ea8ffe232abf03b2034bbd2188bec35a1085f4467d2a7c53->leave($__internal_d012b43f74495387ea8ffe232abf03b2034bbd2188bec35a1085f4467d2a7c53_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xmp\\htdocs\\GGG\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
