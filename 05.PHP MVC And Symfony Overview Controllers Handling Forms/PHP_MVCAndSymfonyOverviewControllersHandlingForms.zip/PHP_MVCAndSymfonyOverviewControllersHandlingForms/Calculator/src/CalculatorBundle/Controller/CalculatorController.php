<?php

namespace CalculatorBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use CalculatorBundle\Entity\Calculator;
use CalculatorBundle\Form\CalculatorType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class CalculatorController extends Controller
{
    /**
     * @param Request $request
     *
     * @Route("/", name="index")
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     */
    public function index(Request $request)
    {
        $calculator = new Calculator();
        // this variable stores our operands and operator

        $form = $this->createForm(CalculatorType::class,$calculator);
        // with this code we take what the user typed in the form and stick it in $calculator

        $form->handleRequest($request);
        // WE PROSSESS THE REQUEST

        //Next we need to check if the form sent by the user exists and if it's valid
        if($form->isSubmitted() && $form->isValid())
        {
            //If our form was submitted and valid, Symfony automatically inserts the form values into our $calculator

            $leftOperand = $calculator->getLeftOperand();
            $rightOperand = $calculator->getRightOperand();
            $operator = $calculator->getOperand();

            $result = 0;

            switch ($operator)
            {
                case "+":
                    $result = $leftOperand + $rightOperand;
                    break;
                case "-":
                    $result = $leftOperand - $rightOperand;
                    break;
                case "*" :
                    $result = $leftOperand * $rightOperand;
                    break;
                case "/":
                    $result = $leftOperand / $rightOperand;

            }
            // after the calculation if everithing went well we need to
            //send an HTTP response to the user with the result

            return $this->render("calculator/index.html.twig",
                ['form' => $form->createView()]);
        }

        return $this->render('calculator/index.html.twig');

    }
}
