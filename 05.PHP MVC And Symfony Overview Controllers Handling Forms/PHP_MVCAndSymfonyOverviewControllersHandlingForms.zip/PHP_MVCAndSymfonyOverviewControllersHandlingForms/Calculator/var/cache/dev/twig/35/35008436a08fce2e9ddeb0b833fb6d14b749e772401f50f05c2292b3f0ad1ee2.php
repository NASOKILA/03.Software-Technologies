<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_4592a34b6ac39b5948bbb51149f4444db563e8d866e7e5b239787aff60b07f26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12ed2cbd32d18bf3025e07d5c39f1bc1c898faef3769cef77d1d343b3e98119c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12ed2cbd32d18bf3025e07d5c39f1bc1c898faef3769cef77d1d343b3e98119c->enter($__internal_12ed2cbd32d18bf3025e07d5c39f1bc1c898faef3769cef77d1d343b3e98119c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_12ed2cbd32d18bf3025e07d5c39f1bc1c898faef3769cef77d1d343b3e98119c->leave($__internal_12ed2cbd32d18bf3025e07d5c39f1bc1c898faef3769cef77d1d343b3e98119c_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_2fab3921219b24f2d00e0318319479497061242d22401f346d05b35d11d3dbe8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fab3921219b24f2d00e0318319479497061242d22401f346d05b35d11d3dbe8->enter($__internal_2fab3921219b24f2d00e0318319479497061242d22401f346d05b35d11d3dbe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_2fab3921219b24f2d00e0318319479497061242d22401f346d05b35d11d3dbe8->leave($__internal_2fab3921219b24f2d00e0318319479497061242d22401f346d05b35d11d3dbe8_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a763757f4a7441b5a71ec84b81df6e5806a955d15c4910b22caa7312ade2cd6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a763757f4a7441b5a71ec84b81df6e5806a955d15c4910b22caa7312ade2cd6b->enter($__internal_a763757f4a7441b5a71ec84b81df6e5806a955d15c4910b22caa7312ade2cd6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a763757f4a7441b5a71ec84b81df6e5806a955d15c4910b22caa7312ade2cd6b->leave($__internal_a763757f4a7441b5a71ec84b81df6e5806a955d15c4910b22caa7312ade2cd6b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d66932d8bfe34d9b0fcae2770848c91a64c9a8910cd483eccddbfc83def16a64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d66932d8bfe34d9b0fcae2770848c91a64c9a8910cd483eccddbfc83def16a64->enter($__internal_d66932d8bfe34d9b0fcae2770848c91a64c9a8910cd483eccddbfc83def16a64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_d66932d8bfe34d9b0fcae2770848c91a64c9a8910cd483eccddbfc83def16a64->leave($__internal_d66932d8bfe34d9b0fcae2770848c91a64c9a8910cd483eccddbfc83def16a64_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
