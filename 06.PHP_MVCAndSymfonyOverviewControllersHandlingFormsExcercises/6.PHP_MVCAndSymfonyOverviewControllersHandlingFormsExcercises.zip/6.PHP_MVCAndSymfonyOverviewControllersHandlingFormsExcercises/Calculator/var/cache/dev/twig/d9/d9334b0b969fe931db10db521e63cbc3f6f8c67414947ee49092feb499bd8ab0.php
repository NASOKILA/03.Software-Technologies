<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_d6015af075bf9857051fb35229ef2045a9f6eb97633b4b81a50f7d780e42fe31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c7adfb65e14eaef1f2221affb17e2c8eb551c2cc3020d5a1d2ee8deba0d63e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c7adfb65e14eaef1f2221affb17e2c8eb551c2cc3020d5a1d2ee8deba0d63e2->enter($__internal_6c7adfb65e14eaef1f2221affb17e2c8eb551c2cc3020d5a1d2ee8deba0d63e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6c7adfb65e14eaef1f2221affb17e2c8eb551c2cc3020d5a1d2ee8deba0d63e2->leave($__internal_6c7adfb65e14eaef1f2221affb17e2c8eb551c2cc3020d5a1d2ee8deba0d63e2_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_29a5f6beecaa1aab94185fc16b0d2cac7ff1b00620026158cf9476e0c4825695 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29a5f6beecaa1aab94185fc16b0d2cac7ff1b00620026158cf9476e0c4825695->enter($__internal_29a5f6beecaa1aab94185fc16b0d2cac7ff1b00620026158cf9476e0c4825695_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_29a5f6beecaa1aab94185fc16b0d2cac7ff1b00620026158cf9476e0c4825695->leave($__internal_29a5f6beecaa1aab94185fc16b0d2cac7ff1b00620026158cf9476e0c4825695_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_e69401d0e19c8aea24d0a168b85febd4ddccb3771bac61d9abfe052eb39ff3f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e69401d0e19c8aea24d0a168b85febd4ddccb3771bac61d9abfe052eb39ff3f8->enter($__internal_e69401d0e19c8aea24d0a168b85febd4ddccb3771bac61d9abfe052eb39ff3f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_e69401d0e19c8aea24d0a168b85febd4ddccb3771bac61d9abfe052eb39ff3f8->leave($__internal_e69401d0e19c8aea24d0a168b85febd4ddccb3771bac61d9abfe052eb39ff3f8_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_172acbd6a7edc00ebb3b2e53fd7d33c983cb26fc869b146f218d529360ee47c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_172acbd6a7edc00ebb3b2e53fd7d33c983cb26fc869b146f218d529360ee47c2->enter($__internal_172acbd6a7edc00ebb3b2e53fd7d33c983cb26fc869b146f218d529360ee47c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_172acbd6a7edc00ebb3b2e53fd7d33c983cb26fc869b146f218d529360ee47c2->leave($__internal_172acbd6a7edc00ebb3b2e53fd7d33c983cb26fc869b146f218d529360ee47c2_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
