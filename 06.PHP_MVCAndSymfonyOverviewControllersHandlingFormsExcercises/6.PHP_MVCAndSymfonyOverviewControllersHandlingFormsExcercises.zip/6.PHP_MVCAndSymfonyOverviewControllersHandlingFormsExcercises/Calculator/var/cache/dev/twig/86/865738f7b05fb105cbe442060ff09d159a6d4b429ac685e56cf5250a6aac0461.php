<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_157fef3f4eb3fb7541db6c80c8fc1669eca6ff8900a7fb72c315413af862e4e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51ed7987f7160b069775378b510e798028297533bd13d468a10c25baa45934f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51ed7987f7160b069775378b510e798028297533bd13d468a10c25baa45934f0->enter($__internal_51ed7987f7160b069775378b510e798028297533bd13d468a10c25baa45934f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_51ed7987f7160b069775378b510e798028297533bd13d468a10c25baa45934f0->leave($__internal_51ed7987f7160b069775378b510e798028297533bd13d468a10c25baa45934f0_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_50ac5a3c0cc5294abee057f69fa016b2c49c81133dbbc8cbb020d1459863eb48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50ac5a3c0cc5294abee057f69fa016b2c49c81133dbbc8cbb020d1459863eb48->enter($__internal_50ac5a3c0cc5294abee057f69fa016b2c49c81133dbbc8cbb020d1459863eb48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_50ac5a3c0cc5294abee057f69fa016b2c49c81133dbbc8cbb020d1459863eb48->leave($__internal_50ac5a3c0cc5294abee057f69fa016b2c49c81133dbbc8cbb020d1459863eb48_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a554e2c53bd114397e706038aaa63f2f48bb31e3c6069014e5093d156f9e9f08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a554e2c53bd114397e706038aaa63f2f48bb31e3c6069014e5093d156f9e9f08->enter($__internal_a554e2c53bd114397e706038aaa63f2f48bb31e3c6069014e5093d156f9e9f08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a554e2c53bd114397e706038aaa63f2f48bb31e3c6069014e5093d156f9e9f08->leave($__internal_a554e2c53bd114397e706038aaa63f2f48bb31e3c6069014e5093d156f9e9f08_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8488819db94762bf2f92ed86468c52c6de6ef0d498fd088e42363a5a67bd10c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8488819db94762bf2f92ed86468c52c6de6ef0d498fd088e42363a5a67bd10c8->enter($__internal_8488819db94762bf2f92ed86468c52c6de6ef0d498fd088e42363a5a67bd10c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_8488819db94762bf2f92ed86468c52c6de6ef0d498fd088e42363a5a67bd10c8->leave($__internal_8488819db94762bf2f92ed86468c52c6de6ef0d498fd088e42363a5a67bd10c8_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
