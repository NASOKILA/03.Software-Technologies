namespace TODOList.Models
{
    using System.Data.Entity;
   
    public class TaskDbContest : DbContext
    {

        // BEZ SLEDNOTO PARCHE KOD VISUAL STUDIO SHTE ZPISHE BAZATA KUDETO SI POISKA
        // A TAKA NIE MU KZVME CHE TOVA TaskDbContest SHTE ZNAE KUDE E BAZATA, KATO GO 
        // OTVORIM SI PISHE
          public TaskDbContest()
            : base("name=TaskDbContest")
        {
        }

         public virtual DbSet<Task> Tasks { get; set; }

    }

    
}