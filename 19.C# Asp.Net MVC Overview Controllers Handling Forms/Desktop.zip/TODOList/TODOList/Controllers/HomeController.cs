﻿
using System.Linq;
using System.Web.Mvc;
using TODOList.Models;

namespace TODOList.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {

            // LETS TAKE ALL THE TASKS FROM THE DB AN PASS THEM TO THE VIEW

            using (var db = new TaskDbContest())
            {

                // Vzimame i vsichi taskove ot bazata
                var tasks = db.Tasks.ToList();

                // i gi podavame na viewto KOETO TRQBVA DA SI SUZDADEM
                return View(tasks);

            }
            
        }
    }
}