<?php

/* base.html.twig */
class __TwigTemplate_3cb91153bae8c255f6ea8eb9702b8f3b410a3b6a804d8d14df3d998c028c8cda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23ec60cc42e55a7511131bb7efeaae5b3941123d2481760c4eb73fb4db03970d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23ec60cc42e55a7511131bb7efeaae5b3941123d2481760c4eb73fb4db03970d->enter($__internal_23ec60cc42e55a7511131bb7efeaae5b3941123d2481760c4eb73fb4db03970d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 75
        echo "
<div class=\"container body-container\">
    ";
        // line 77
        $this->displayBlock('body', $context, $blocks);
        // line 84
        echo "</div>

";
        // line 86
        $this->displayBlock('footer', $context, $blocks);
        // line 93
        echo "
";
        // line 94
        $this->displayBlock('javascripts', $context, $blocks);
        // line 100
        echo "
</body>
</html>
";
        
        $__internal_23ec60cc42e55a7511131bb7efeaae5b3941123d2481760c4eb73fb4db03970d->leave($__internal_23ec60cc42e55a7511131bb7efeaae5b3941123d2481760c4eb73fb4db03970d_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_dd155a1fe55719e57e6caf1d00491456e41a023eb7fd30b79694a2e53ca72ff8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd155a1fe55719e57e6caf1d00491456e41a023eb7fd30b79694a2e53ca72ff8->enter($__internal_dd155a1fe55719e57e6caf1d00491456e41a023eb7fd30b79694a2e53ca72ff8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "SoftUni Blog";
        
        $__internal_dd155a1fe55719e57e6caf1d00491456e41a023eb7fd30b79694a2e53ca72ff8->leave($__internal_dd155a1fe55719e57e6caf1d00491456e41a023eb7fd30b79694a2e53ca72ff8_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e707e37bb6911f5d8f49fbba6701b0bb7b1225aa0379ded6125e6ea5d398ffab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e707e37bb6911f5d8f49fbba6701b0bb7b1225aa0379ded6125e6ea5d398ffab->enter($__internal_e707e37bb6911f5d8f49fbba6701b0bb7b1225aa0379ded6125e6ea5d398ffab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_e707e37bb6911f5d8f49fbba6701b0bb7b1225aa0379ded6125e6ea5d398ffab->leave($__internal_e707e37bb6911f5d8f49fbba6701b0bb7b1225aa0379ded6125e6ea5d398ffab_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_2a2ed5201e2a70c6de47a42f89953dd635a1510397d0620f720364309c0b3c38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a2ed5201e2a70c6de47a42f89953dd635a1510397d0620f720364309c0b3c38->enter($__internal_2a2ed5201e2a70c6de47a42f89953dd635a1510397d0620f720364309c0b3c38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_2a2ed5201e2a70c6de47a42f89953dd635a1510397d0620f720364309c0b3c38->leave($__internal_2a2ed5201e2a70c6de47a42f89953dd635a1510397d0620f720364309c0b3c38_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_453c418dda9a5fda5a1374a22a45f7ba03984e181d866d127cf1c125a69f4805 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_453c418dda9a5fda5a1374a22a45f7ba03984e181d866d127cf1c125a69f4805->enter($__internal_453c418dda9a5fda5a1374a22a45f7ba03984e181d866d127cf1c125a69f4805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        ";
        // line 36
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 37
            echo "                            <li>
                                <a href=\"";
            // line 38
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("books_list");
            echo "\">
                                    All Books
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 43
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("books_create");
            echo "\">
                                    Create Book
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 48
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profile");
            echo "\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 53
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">
                                    Logout
                                </a>
                            </li>
                        ";
        } else {
            // line 58
            echo "                            <li>
                                <a href=\"";
            // line 59
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_register");
            echo "\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 64
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
            echo "\">
                                    LOGIN
                                </a>
                            </li>
                        ";
        }
        // line 69
        echo "                    </ul>
                </div>
            </div>
        </div>
    </header>
";
        
        $__internal_453c418dda9a5fda5a1374a22a45f7ba03984e181d866d127cf1c125a69f4805->leave($__internal_453c418dda9a5fda5a1374a22a45f7ba03984e181d866d127cf1c125a69f4805_prof);

    }

    // line 77
    public function block_body($context, array $blocks = array())
    {
        $__internal_3ceb5de8f600308b75a5c886bd43029bac487337e4fb6fb5476864fa88fe2978 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ceb5de8f600308b75a5c886bd43029bac487337e4fb6fb5476864fa88fe2978->enter($__internal_3ceb5de8f600308b75a5c886bd43029bac487337e4fb6fb5476864fa88fe2978_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 78
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 80
        $this->displayBlock('main', $context, $blocks);
        // line 81
        echo "            </div>
        </div>
    ";
        
        $__internal_3ceb5de8f600308b75a5c886bd43029bac487337e4fb6fb5476864fa88fe2978->leave($__internal_3ceb5de8f600308b75a5c886bd43029bac487337e4fb6fb5476864fa88fe2978_prof);

    }

    // line 80
    public function block_main($context, array $blocks = array())
    {
        $__internal_d59c2be5ec2eae27ec2b35e60f0d3ad6a23c49c007a8b7c2ddd93c6a3acdc1bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d59c2be5ec2eae27ec2b35e60f0d3ad6a23c49c007a8b7c2ddd93c6a3acdc1bb->enter($__internal_d59c2be5ec2eae27ec2b35e60f0d3ad6a23c49c007a8b7c2ddd93c6a3acdc1bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_d59c2be5ec2eae27ec2b35e60f0d3ad6a23c49c007a8b7c2ddd93c6a3acdc1bb->leave($__internal_d59c2be5ec2eae27ec2b35e60f0d3ad6a23c49c007a8b7c2ddd93c6a3acdc1bb_prof);

    }

    // line 86
    public function block_footer($context, array $blocks = array())
    {
        $__internal_8e7159ab4a84169f064609ae6ad1c3c5f572e9d3889898742897bf111213c1c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e7159ab4a84169f064609ae6ad1c3c5f572e9d3889898742897bf111213c1c4->enter($__internal_8e7159ab4a84169f064609ae6ad1c3c5f572e9d3889898742897bf111213c1c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 87
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_8e7159ab4a84169f064609ae6ad1c3c5f572e9d3889898742897bf111213c1c4->leave($__internal_8e7159ab4a84169f064609ae6ad1c3c5f572e9d3889898742897bf111213c1c4_prof);

    }

    // line 94
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_777631055a24025d68cf6d4ad706e66f80f4e59264324892a6895da44ec0194b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_777631055a24025d68cf6d4ad706e66f80f4e59264324892a6895da44ec0194b->enter($__internal_777631055a24025d68cf6d4ad706e66f80f4e59264324892a6895da44ec0194b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 95
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 96
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 97
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 98
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_777631055a24025d68cf6d4ad706e66f80f4e59264324892a6895da44ec0194b->leave($__internal_777631055a24025d68cf6d4ad706e66f80f4e59264324892a6895da44ec0194b_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  289 => 98,  285 => 97,  281 => 96,  276 => 95,  270 => 94,  258 => 87,  252 => 86,  241 => 80,  232 => 81,  230 => 80,  226 => 78,  220 => 77,  208 => 69,  200 => 64,  192 => 59,  189 => 58,  181 => 53,  173 => 48,  165 => 43,  157 => 38,  154 => 37,  152 => 36,  139 => 26,  133 => 22,  127 => 21,  116 => 19,  107 => 14,  102 => 13,  96 => 12,  84 => 11,  74 => 100,  72 => 94,  69 => 93,  67 => 86,  63 => 84,  61 => 77,  57 => 75,  55 => 21,  50 => 19,  43 => 16,  41 => 12,  37 => 11,  30 => 6,);
    }

    public function getSource()
    {
        return "{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}SoftUni Blog{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('blog_index') }}\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        {% if app.user %}
                            <li>
                                <a href=\"{{ path('books_list') }}\">
                                    All Books
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('books_create') }}\">
                                    Create Book
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('user_profile') }}\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_logout') }}\">
                                    Logout
                                </a>
                            </li>
                        {% else %}
                            <li>
                                <a href=\"{{ path('user_register') }}\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_login') }}\">
                                    LOGIN
                                </a>
                            </li>
                        {% endif %}
                    </ul>
                </div>
            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
";
    }
}
