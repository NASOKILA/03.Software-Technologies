<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_9d4f6bb49613a5edfcad2c54aa4e139163925f39ca3fa0adbf97de3d95d8d077 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aab60936d857988e86a62545b44b47e358190e077841002ba9d396ede821b9dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aab60936d857988e86a62545b44b47e358190e077841002ba9d396ede821b9dc->enter($__internal_aab60936d857988e86a62545b44b47e358190e077841002ba9d396ede821b9dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aab60936d857988e86a62545b44b47e358190e077841002ba9d396ede821b9dc->leave($__internal_aab60936d857988e86a62545b44b47e358190e077841002ba9d396ede821b9dc_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_9eeb3ccf4ec88d8224a6f96540065972fd7078577f0743785b707a151e5ddfd5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9eeb3ccf4ec88d8224a6f96540065972fd7078577f0743785b707a151e5ddfd5->enter($__internal_9eeb3ccf4ec88d8224a6f96540065972fd7078577f0743785b707a151e5ddfd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_9eeb3ccf4ec88d8224a6f96540065972fd7078577f0743785b707a151e5ddfd5->leave($__internal_9eeb3ccf4ec88d8224a6f96540065972fd7078577f0743785b707a151e5ddfd5_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_f039c62b67dc748cdd4192991946aa6f87b92db0a301687fff94e62d17324f7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f039c62b67dc748cdd4192991946aa6f87b92db0a301687fff94e62d17324f7b->enter($__internal_f039c62b67dc748cdd4192991946aa6f87b92db0a301687fff94e62d17324f7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_f039c62b67dc748cdd4192991946aa6f87b92db0a301687fff94e62d17324f7b->leave($__internal_f039c62b67dc748cdd4192991946aa6f87b92db0a301687fff94e62d17324f7b_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_5abbb705fa21c79162ff7fb488d65303c77b344285445ceb9ef855e7e462a439 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5abbb705fa21c79162ff7fb488d65303c77b344285445ceb9ef855e7e462a439->enter($__internal_5abbb705fa21c79162ff7fb488d65303c77b344285445ceb9ef855e7e462a439_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_5abbb705fa21c79162ff7fb488d65303c77b344285445ceb9ef855e7e462a439->leave($__internal_5abbb705fa21c79162ff7fb488d65303c77b344285445ceb9ef855e7e462a439_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
