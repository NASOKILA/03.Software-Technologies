<?php

/* books/list.html.twig */
class __TwigTemplate_add0a2b4173f52e41b673a9d2af7d3f162a90c6a5daa8c0a3abab1c156b48cf9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "books/list.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc8b71324c91c67ae51125ddf5711b9f0d38bcdf4c49be31880ca205e7119f0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc8b71324c91c67ae51125ddf5711b9f0d38bcdf4c49be31880ca205e7119f0c->enter($__internal_cc8b71324c91c67ae51125ddf5711b9f0d38bcdf4c49be31880ca205e7119f0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "books/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cc8b71324c91c67ae51125ddf5711b9f0d38bcdf4c49be31880ca205e7119f0c->leave($__internal_cc8b71324c91c67ae51125ddf5711b9f0d38bcdf4c49be31880ca205e7119f0c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f12d7ad0014d1457d96cb776070f8faee6f4c40c554f222fb9717420b647cc45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f12d7ad0014d1457d96cb776070f8faee6f4c40c554f222fb9717420b647cc45->enter($__internal_f12d7ad0014d1457d96cb776070f8faee6f4c40c554f222fb9717420b647cc45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container body-content\">
        <div class=\"row\">
            ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["books"]) ? $context["books"] : $this->getContext($context, "books")));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 8
            echo "                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "name", array()), "html", null, true);
            echo "</h2>
                        </header>

                        <p>
                            ";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "iSBN", array()), "html", null, true);
            echo "
                        </p>

                        <small class=\"author\">
                            ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "author", array()), "html", null, true);
            echo "
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", array()), "html", null, true);
            echo "\">Open Book&raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "        </div>
    </div>


";
        
        $__internal_f12d7ad0014d1457d96cb776070f8faee6f4c40c554f222fb9717420b647cc45->leave($__internal_f12d7ad0014d1457d96cb776070f8faee6f4c40c554f222fb9717420b647cc45_prof);

    }

    public function getTemplateName()
    {
        return "books/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 31,  77 => 25,  68 => 19,  61 => 15,  54 => 11,  49 => 8,  45 => 7,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container body-content\">
        <div class=\"row\">
            {% for book in books%}
                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>{{ book.name}}</h2>
                        </header>

                        <p>
                            {{ book.iSBN}}
                        </p>

                        <small class=\"author\">
                            {{ book.author }}
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"{{ book.id }}\">Open Book&raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            {% endfor %}
        </div>
    </div>


{% endblock %}";
    }
}
