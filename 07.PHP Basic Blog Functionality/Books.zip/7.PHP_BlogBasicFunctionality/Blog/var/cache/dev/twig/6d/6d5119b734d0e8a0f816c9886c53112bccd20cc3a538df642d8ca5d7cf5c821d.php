<?php

/* articles/list.html.twig */
class __TwigTemplate_e0c825fd7dea4c9d1c27b229e92fbe2b771ad34adfcdd8d222760236cee980c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "articles/list.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e96d7073b3bf1b29da59310ed5e0c7ae55f4be5463d0dbb20208defcee684f35 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e96d7073b3bf1b29da59310ed5e0c7ae55f4be5463d0dbb20208defcee684f35->enter($__internal_e96d7073b3bf1b29da59310ed5e0c7ae55f4be5463d0dbb20208defcee684f35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "articles/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e96d7073b3bf1b29da59310ed5e0c7ae55f4be5463d0dbb20208defcee684f35->leave($__internal_e96d7073b3bf1b29da59310ed5e0c7ae55f4be5463d0dbb20208defcee684f35_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_44c98fb1af0a62df2d9d93438b781d1d0ba4e42c4c5ad7e7f09c546d46a723b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44c98fb1af0a62df2d9d93438b781d1d0ba4e42c4c5ad7e7f09c546d46a723b1->enter($__internal_44c98fb1af0a62df2d9d93438b781d1d0ba4e42c4c5ad7e7f09c546d46a723b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container body-content\">
        <div class=\"row\">
            ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["articles"]) ? $context["articles"] : $this->getContext($context, "articles")));
        foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
            // line 8
            echo "                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["article"], "title", array()), "html", null, true);
            echo "</h2>
                        </header>

                        <p>
                            ";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["article"], "summary", array()), "html", null, true);
            echo "
                        </p>

                        <small class=\"author\">
                            ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["article"], "author", array()), "html", null, true);
            echo "
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["article"], "id", array()), "html", null, true);
            echo "\">Read more &raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "        </div>
    </div>


";
        
        $__internal_44c98fb1af0a62df2d9d93438b781d1d0ba4e42c4c5ad7e7f09c546d46a723b1->leave($__internal_44c98fb1af0a62df2d9d93438b781d1d0ba4e42c4c5ad7e7f09c546d46a723b1_prof);

    }

    public function getTemplateName()
    {
        return "articles/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 31,  77 => 25,  68 => 19,  61 => 15,  54 => 11,  49 => 8,  45 => 7,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container body-content\">
        <div class=\"row\">
            {% for article in articles %}
                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>{{ article.title }}</h2>
                        </header>

                        <p>
                            {{ article.summary }}
                        </p>

                        <small class=\"author\">
                            {{ article.author }}
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"{{ article.id }}\">Read more &raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            {% endfor %}
        </div>
    </div>


{% endblock %}";
    }
}
