<?php

/* list.html.twig */
class __TwigTemplate_161f11732b0aca00b329904c2bccdd5250c842a8fe9c1c4c957107224e8f6a56 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "list.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d72c437c012b8a26b5355edab9d0f8a258f2467969644a8fe54efc3a203a4510 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d72c437c012b8a26b5355edab9d0f8a258f2467969644a8fe54efc3a203a4510->enter($__internal_d72c437c012b8a26b5355edab9d0f8a258f2467969644a8fe54efc3a203a4510_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d72c437c012b8a26b5355edab9d0f8a258f2467969644a8fe54efc3a203a4510->leave($__internal_d72c437c012b8a26b5355edab9d0f8a258f2467969644a8fe54efc3a203a4510_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_49626336035a26b3171fe2207743e8c1e96e4b3cb83ec187dc02390c09e4cf95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49626336035a26b3171fe2207743e8c1e96e4b3cb83ec187dc02390c09e4cf95->enter($__internal_49626336035a26b3171fe2207743e8c1e96e4b3cb83ec187dc02390c09e4cf95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container body-content\">
        <div class=\"row\">
            ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")));
        foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
            // line 8
            echo "                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>Title</h2>
                        </header>

                        <p>
                            Content
                        </p>

                        <small class=\"author\">
                            Author
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"#\">Read more &raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "        </div>
    </div>


";
        
        $__internal_49626336035a26b3171fe2207743e8c1e96e4b3cb83ec187dc02390c09e4cf95->leave($__internal_49626336035a26b3171fe2207743e8c1e96e4b3cb83ec187dc02390c09e4cf95_prof);

    }

    public function getTemplateName()
    {
        return "list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 31,  49 => 8,  45 => 7,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container body-content\">
        <div class=\"row\">
            {% for article in a%}
                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>Title</h2>
                        </header>

                        <p>
                            Content
                        </p>

                        <small class=\"author\">
                            Author
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"#\">Read more &raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            {% endfor %}
        </div>
    </div>


{% endblock %}





";
    }
}
