<?php

/* books/show.html.twig */
class __TwigTemplate_41a2386e6705555c963c040f61aa1c87668f36f4934af9f7222b0599af794b95 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "books/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c753402dba2e59e994e483c7df633ae5367e32c3a02a0161f68679de1a300b4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c753402dba2e59e994e483c7df633ae5367e32c3a02a0161f68679de1a300b4b->enter($__internal_c753402dba2e59e994e483c7df633ae5367e32c3a02a0161f68679de1a300b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "books/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c753402dba2e59e994e483c7df633ae5367e32c3a02a0161f68679de1a300b4b->leave($__internal_c753402dba2e59e994e483c7df633ae5367e32c3a02a0161f68679de1a300b4b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_17b550e2e059a31cc5c3d14f4ae3f93102481ed4e1598cb80939fa1e62de1a9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17b550e2e059a31cc5c3d14f4ae3f93102481ed4e1598cb80939fa1e62de1a9a->enter($__internal_17b550e2e059a31cc5c3d14f4ae3f93102481ed4e1598cb80939fa1e62de1a9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-6\">
                <article>
                    <header>
                        <h2>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["book"]) ? $context["book"] : $this->getContext($context, "book")), "name", array()), "html", null, true);
        echo "</h2>
                    </header>

                    <p>
                        ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["book"]) ? $context["book"] : $this->getContext($context, "book")), "iSBN", array()), "html", null, true);
        echo "
                    </p>

                    <small class=\"author\">
                        ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["book"]) ? $context["book"] : $this->getContext($context, "book")), "author", array()), "html", null, true);
        echo "
                    </small>
                    <footer>
                        <div class=\"pull-right\">
                            <a class=\"btn btn-default btn-xs\" href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("books_list");
        echo "\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>


";
        
        $__internal_17b550e2e059a31cc5c3d14f4ae3f93102481ed4e1598cb80939fa1e62de1a9a->leave($__internal_17b550e2e059a31cc5c3d14f4ae3f93102481ed4e1598cb80939fa1e62de1a9a_prof);

    }

    public function getTemplateName()
    {
        return "books/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-6\">
                <article>
                    <header>
                        <h2>{{ book.name}}</h2>
                    </header>

                    <p>
                        {{ book.iSBN}}
                    </p>

                    <small class=\"author\">
                        {{ book.author }}
                    </small>
                    <footer>
                        <div class=\"pull-right\">
                            <a class=\"btn btn-default btn-xs\" href=\"{{ path('books_list') }}\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>


{% endblock %}";
    }
}
