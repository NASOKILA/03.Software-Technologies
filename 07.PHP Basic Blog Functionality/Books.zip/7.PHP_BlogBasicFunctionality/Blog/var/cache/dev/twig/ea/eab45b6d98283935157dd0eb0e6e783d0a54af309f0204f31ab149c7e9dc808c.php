<?php

/* books/create.html.twig */
class __TwigTemplate_38b6159eb2bb50db894045e6d230018c394cc5c44e2c75a64121c0e52bf31fdf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "books/create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3be8324a7f7ff5ff53285cae09dd3d5595f3c22baaae5266362ac06f4a09d4a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3be8324a7f7ff5ff53285cae09dd3d5595f3c22baaae5266362ac06f4a09d4a9->enter($__internal_3be8324a7f7ff5ff53285cae09dd3d5595f3c22baaae5266362ac06f4a09d4a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "books/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3be8324a7f7ff5ff53285cae09dd3d5595f3c22baaae5266362ac06f4a09d4a9->leave($__internal_3be8324a7f7ff5ff53285cae09dd3d5595f3c22baaae5266362ac06f4a09d4a9_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_1cf0c9860ec1c147264d35d725cf0706bb10b82526b7cd542bfa5b6d5c5fd122 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1cf0c9860ec1c147264d35d725cf0706bb10b82526b7cd542bfa5b6d5c5fd122->enter($__internal_1cf0c9860ec1c147264d35d725cf0706bb10b82526b7cd542bfa5b6d5c5fd122_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("books_create");
        echo "\" method=\"POST\">
                <fieldset>
                    <legend>New Book</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Book Name</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\"
                                   name=\"book[name]\">
                        </div>
                    </div>



                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Book ISBN</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\"
                                   name=\"book[iSBN]\">
                        </div>
                    </div>


                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Book Author</label>
                        <div class=\"col-sm-6\">
                        <input class=\"form-control\" rows=\"6\" id=\"article_content\"
                                  name=\"book[author]\"></input>
                        </div>
                    </div>

                    ";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("books_list");
        echo "\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>

";
        
        $__internal_1cf0c9860ec1c147264d35d725cf0706bb10b82526b7cd542bfa5b6d5c5fd122->leave($__internal_1cf0c9860ec1c147264d35d725cf0706bb10b82526b7cd542bfa5b6d5c5fd122_prof);

    }

    public function getTemplateName()
    {
        return "books/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 42,  79 => 38,  45 => 7,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"{{ path('books_create') }}\" method=\"POST\">
                <fieldset>
                    <legend>New Book</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Book Name</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\"
                                   name=\"book[name]\">
                        </div>
                    </div>



                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Book ISBN</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\"
                                   name=\"book[iSBN]\">
                        </div>
                    </div>


                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Book Author</label>
                        <div class=\"col-sm-6\">
                        <input class=\"form-control\" rows=\"6\" id=\"article_content\"
                                  name=\"book[author]\"></input>
                        </div>
                    </div>

                    {{ form_row(form._token) }}

                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"{{ path('books_list') }}\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>

{% endblock %}";
    }
}
