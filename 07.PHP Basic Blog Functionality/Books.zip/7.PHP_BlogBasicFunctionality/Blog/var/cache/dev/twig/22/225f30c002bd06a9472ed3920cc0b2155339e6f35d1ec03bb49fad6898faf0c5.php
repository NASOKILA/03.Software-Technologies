<?php

/* blog/index.html.twig */
class __TwigTemplate_fa0d6d7a18414d370b6d9a6825dec955422515eea6b945c0df56d8b01a552097 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b27e75b033db5a851e9f8668f72d5c5d4f508ef3b745891cec2e59f80909ece = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b27e75b033db5a851e9f8668f72d5c5d4f508ef3b745891cec2e59f80909ece->enter($__internal_4b27e75b033db5a851e9f8668f72d5c5d4f508ef3b745891cec2e59f80909ece_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b27e75b033db5a851e9f8668f72d5c5d4f508ef3b745891cec2e59f80909ece->leave($__internal_4b27e75b033db5a851e9f8668f72d5c5d4f508ef3b745891cec2e59f80909ece_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_c78d6298a04eb37dd0d250206923602b86d9b5949ed5eadac2e0ada181319c59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c78d6298a04eb37dd0d250206923602b86d9b5949ed5eadac2e0ada181319c59->enter($__internal_c78d6298a04eb37dd0d250206923602b86d9b5949ed5eadac2e0ada181319c59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        
        $__internal_c78d6298a04eb37dd0d250206923602b86d9b5949ed5eadac2e0ada181319c59->leave($__internal_c78d6298a04eb37dd0d250206923602b86d9b5949ed5eadac2e0ada181319c59_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block main %}

{% endblock %}
";
    }
}
